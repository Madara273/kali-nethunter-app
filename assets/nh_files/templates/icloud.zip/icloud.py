# content file: icloud.py
from wifipumpkin3.plugins.captiveflask.plugin import CaptiveTemplatePlugin
import wifipumpkin3.core.utility.constants as C

class Icloud(CaptiveTemplatePlugin):
    Name = "icloud"
    Version = "1.0"
    Description = "Template for icloud page login"
    Author = "Dr.rootsu"
    TemplatePath = C.TEMPLATES_FLASK + "templates/icloud"
    StaticPath = C.TEMPLATES_FLASK + "templates/icloud/static"
    Preview = C.TEMPLATES_FLASK + "templates/icloud/preview.png"